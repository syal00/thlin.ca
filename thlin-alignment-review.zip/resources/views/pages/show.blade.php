@extends('layouts.app')

@section('title', $page->title.' - '.$thlin['name'])
@section('meta_description', $page->excerpt)

@section('content')

@if ($page->section === 'about' && $page->slug === 'us')

<section class="about-hero">
    <div class="container about-hero-grid">
        <div>
            <div class="about-breadcrumb">
                <a href="{{ route('home') }}">Home</a>
                <span>/</span>
                <span>About</span>
                <span>/</span>
                <span>{{ $page->title }}</span>
            </div>

            <span class="section-kicker">About THLIN</span>

            <h1
                data-editable="true"
                data-model="page"
                data-id="{{ $page->id }}"
                data-field="title"
            >{{ $page->title }}</h1>

            @if ($page->excerpt)
                <p
                    class="about-hero-text"
                    data-editable="true"
                    data-model="page"
                    data-id="{{ $page->id }}"
                    data-field="excerpt"
                >{{ $page->excerpt }}</p>
            @endif

            <div class="about-actions">
                <a href="{{ route('contact') }}" class="about-btn about-btn-primary">Contact Us</a>
                <a href="{{ route('pages.show', ['section' => 'about', 'page' => 'board']) }}" class="about-btn about-btn-secondary">Meet Our Board</a>
            </div>
        </div>

        <aside class="about-hero-card">
            <span class="about-card-label">Founded</span>
            <strong>2001</strong>
            <p>
                Supporting Ontario communities with trusted digital health and community service information.
            </p>

            <div class="about-mini-stats">
                <div>
                    <span>20+</span>
                    <p>Years of service</p>
                </div>
                <div>
                    <span>Ontario</span>
                    <p>Service focus</p>
                </div>
            </div>
        </aside>
    </div>
</section>

<section class="about-content-section">
    <div class="container about-content-grid">
        <article class="about-main-card">
            <span class="section-kicker blue">Our Story</span>

            <div
                class="about-rich-content"
                data-editable="true"
                data-model="page"
                data-id="{{ $page->id }}"
                data-field="body"
            >
                {!! \App\Support\AboutBodyFormatter::render($page->body) !!}
            </div>

            @if ($page->updated_at)
                <p class="content-updated">Last updated: {{ $page->updated_at->format('F j, Y') }}</p>
            @endif

            <a href="{{ route('contact') }}" class="about-story-btn">Contact Us</a>
        </article>

        <aside class="about-side-card">
            <h2>About THLIN</h2>
            <ul>
                <li><a href="{{ route('pages.show', ['section' => 'about', 'page' => 'us']) }}">Our Story</a></li>
                <li><a href="{{ route('pages.show', ['section' => 'about', 'page' => 'board']) }}">Board</a></li>
                <li><a href="{{ route('pages.show', ['section' => 'about', 'page' => 'annual-reports']) }}">Annual Reports</a></li>
                <li><a href="{{ route('pages.show', ['section' => 'about', 'page' => 'news']) }}">News</a></li>
                <li><a href="{{ route('pages.show', ['section' => 'about', 'page' => 'careers']) }}">Careers</a></li>
            </ul>
        </aside>
    </div>
</section>

<section class="related-pages-section" aria-label="Related Pages">
    <div class="container">
        <div class="related-pages-header">
            <span class="section-kicker blue">Related Pages</span>
            <h2>Learn more about THLIN</h2>
            <p>Explore our organization, governance, updates, and opportunities.</p>
        </div>

        <div class="related-pages-grid">
            <a class="related-page-card" href="{{ route('pages.show', ['section' => 'about', 'page' => 'board']) }}">
                <span>01</span>
                <h3>Board</h3>
                <p>Learn more about THLIN leadership and governance.</p>
            </a>

            <a class="related-page-card" href="{{ route('pages.show', ['section' => 'about', 'page' => 'annual-reports']) }}">
                <span>02</span>
                <h3>Annual Reports</h3>
                <p>View organizational reports and updates.</p>
            </a>

            <a class="related-page-card" href="{{ route('pages.show', ['section' => 'about', 'page' => 'news']) }}">
                <span>03</span>
                <h3>News</h3>
                <p>Read the latest THLIN news and announcements.</p>
            </a>

            <a class="related-page-card" href="{{ route('pages.show', ['section' => 'about', 'page' => 'careers']) }}">
                <span>04</span>
                <h3>Careers</h3>
                <p>Explore opportunities to work with THLIN.</p>
            </a>
        </div>
    </div>
</section>

@include('partials.page-cta')

@elseif (in_array($page->section, ['products', 'partners'], true))

@include('partials.capability-page', ['page' => $page, 'section' => $page->section])

@include('partials.page-cta')

@else

<section class="page-content-section">
    <div class="container page-content-card">
        <h1
            data-editable="true"
            data-model="page"
            data-id="{{ $page->id }}"
            data-field="title"
        >{{ $page->title }}</h1>

        @if ($page->excerpt)
            <p
                class="page-excerpt"
                data-editable="true"
                data-model="page"
                data-id="{{ $page->id }}"
                data-field="excerpt"
            >{{ $page->excerpt }}</p>
        @endif

        <div
            data-editable="true"
            data-model="page"
            data-id="{{ $page->id }}"
            data-field="body"
        >
            {!! $page->body !!}
        </div>

        @if ($page->updated_at)
            <p class="content-updated">Last updated: {{ $page->updated_at->format('F j, Y') }}</p>
        @endif
    </div>
</section>

@includeIf('partials.page-cta')

@endif

@endsection