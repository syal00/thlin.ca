@extends('layouts.app')

@section('title', ($page->meta_title ?: $page->title).' - '.$thlin['name'])

@if (! empty($page->meta_keywords))
    @push('head')
        <meta name="keywords" content="{{ $page->meta_keywords }}">
    @endpush
@endif

@section('hero')
    @include('partials.page-header', ['page' => $page, 'eyebrow' => 'Leadership'])
@endsection

@section('content')
    <section class="home-section section-light">
        <div class="section-container">
            <div class="content-shell">
                {{-- Board member cards are rendered by the .board-grid loop below ($members).
                     The page body field currently duplicates that grid (imported legacy HTML with
                     headshots/bios). Clear body via /admin → Pages → Board of Directors — keep
                     only a short intro sentence if needed; the grid is the single source of truth. --}}
                @if ($page->body || auth()->check())
                    @auth
                        <div class="cms-content" @include('partials.inline-edit-attrs', ['model' => 'page', 'id' => $page->id, 'field' => 'body', 'type' => 'richtext'])>
                            @include('partials.cms-body', ['html' => $page->body])
                        </div>
                    @else
                        <div class="cms-content">@include('partials.cms-body', ['html' => $page->body])</div>
                    @endauth
                @endif

                @include('partials.page-updated', ['page' => $page])

                <div class="board-grid">
                    @foreach ($members as $member)
                        <article class="board-card service-card">
                            @if ($member->photoUrl())
                                <img src="{{ $member->photoUrl() }}" alt="{{ $member->name }}" class="board-photo">
                            @endif
                            <h2 @include('partials.inline-edit-attrs', ['model' => 'board', 'id' => $member->id, 'field' => 'name', 'type' => 'text'])>{{ $member->name }}</h2>
                            <p class="board-role" @include('partials.inline-edit-attrs', ['model' => 'board', 'id' => $member->id, 'field' => 'role', 'type' => 'text'])>{{ $member->role }}</p>
                            <p @include('partials.inline-edit-attrs', ['model' => 'board', 'id' => $member->id, 'field' => 'bio', 'type' => 'richtext'])>{!! $member->bio !!}</p>
                        </article>
                    @endforeach
                </div>
            </div>
        </div>
    </section>

    @include('partials.page-cta')
@endsection
