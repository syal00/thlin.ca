@php
    $sectionKey = $section ?? $page->section;
    $isPartners = $sectionKey === 'partners';

    $sectionLabel = $isPartners ? 'Partners' : 'Products &amp; Services';
    $sectionKicker = $isPartners ? 'Partners' : 'Products &amp; Services';
    $breadcrumbParent = $isPartners ? 'Partners' : 'Products &amp; Services';

    $defaultExcerpt = $isPartners
        ? 'Digital tools and information resources tailored for your organization.'
        : 'Helping patients, caregivers, providers, and community partners find reliable service information across Ontario.';
@endphp

<section class="service-detail-hero">
    <div class="container service-detail-grid">
        <div class="service-detail-copy">
            <div class="service-breadcrumb">
                <a href="{{ route('home') }}">Home</a>
                <span>/</span>
                <span>{{ $breadcrumbParent }}</span>
                <span>/</span>
                <span>{{ $page->title }}</span>
            </div>

            <span class="section-kicker">{{ $sectionKicker }}</span>

            <h1
                data-editable="true"
                data-model="page"
                data-id="{{ $page->id }}"
                data-field="title"
            >{{ $page->title }}</h1>

            <p
                class="service-detail-excerpt"
                data-editable="true"
                data-model="page"
                data-id="{{ $page->id }}"
                data-field="excerpt"
            >{{ $page->excerpt ?: $defaultExcerpt }}</p>

            <div class="service-detail-actions">
                <a href="{{ route('search') }}" class="service-btn service-btn-light">Find Services</a>
                <a href="{{ route('contact') }}" class="service-btn service-btn-outline">Contact THLIN</a>
            </div>
        </div>

        <aside class="service-hero-card">
            <h2>{{ $isPartners ? 'How We Partner' : 'What You Get' }}</h2>
            <ul class="service-highlight-list">
                <li>
                    <strong>Audience-Specific Tools</strong>
                    <span>Content and capabilities shaped for your sector and users.</span>
                </li>
                <li>
                    <strong>Trusted Information</strong>
                    <span>Built on THLIN's validated service directory and data practices.</span>
                </li>
                <li>
                    <strong>Practical Support</strong>
                    <span>Implementation, training, and ongoing partnership options.</span>
                </li>
            </ul>
        </aside>
    </div>
</section>

<section class="service-detail-content">
    <div class="container service-content-grid">
        <article class="service-main-card service-pro-card product-main-content-card">
            <div
                class="service-rich-content capability-page-body"
                data-editable="true"
                data-model="page"
                data-id="{{ $page->id }}"
                data-field="body"
            >
                @include('partials.cms-body', ['html' => $page->body])
            </div>

            @if ($page->updated_at)
                <p class="page-last-updated">
                    Last updated: {{ $page->updated_at->format('F j, Y') }}
                </p>
            @endif
        </article>

        <aside class="service-side-card service-pro-sidebar">
            <span class="sidebar-label">Explore</span>
            <h2>{{ $isPartners ? 'Partner Solutions' : 'Explore Services' }}</h2>
            <nav class="service-sidebar-nav" aria-label="{{ $isPartners ? 'Partner solutions' : 'Explore services' }}">
                @if ($isPartners)
                    <a href="{{ route('pages.show', ['section' => 'partners', 'page' => 'health-care']) }}">
                        <span>Health Care</span>
                        <strong>→</strong>
                    </a>
                    <a href="{{ route('pages.show', ['section' => 'partners', 'page' => 'municipalities']) }}">
                        <span>Municipalities</span>
                        <strong>→</strong>
                    </a>
                    <a href="{{ route('pages.show', ['section' => 'partners', 'page' => 'social-services']) }}">
                        <span>Social Services</span>
                        <strong>→</strong>
                    </a>
                    <a href="{{ route('pages.show', ['section' => 'partners', 'page' => 'ontario-health-teams']) }}">
                        <span>Ontario Health Teams</span>
                        <strong>→</strong>
                    </a>
                @else
                    <a href="{{ route('pages.show', ['section' => 'products', 'page' => 'healthline']) }}">
                        <span>thehealthline.ca</span>
                        <strong>→</strong>
                    </a>
                    <a href="{{ route('pages.show', ['section' => 'products', 'page' => 'patient-portals']) }}">
                        <span>Patient Portals</span>
                        <strong>→</strong>
                    </a>
                    <a href="{{ route('pages.show', ['section' => 'products', 'page' => 'provider-portals']) }}">
                        <span>Provider Portals</span>
                        <strong>→</strong>
                    </a>
                    <a href="{{ route('pages.show', ['section' => 'products', 'page' => 'information-management']) }}">
                        <span>Information Management</span>
                        <strong>→</strong>
                    </a>
                @endif

                <a href="{{ route('contact') }}">
                    <span>Contact THLIN</span>
                    <strong>→</strong>
                </a>
            </nav>
        </aside>
    </div>
</section>

@if ($page->slug === 'healthline')
    <section class="service-feature-cards-section full-width-section" aria-label="Service Features">
        <div class="container">
            <div class="service-feature-heading">
                <span class="section-kicker blue">Service Features</span>
                <h2>Built to make service information easier to find and use</h2>
                <p>
                    thehealthline.ca helps people, caregivers, providers, and community partners access trusted
                    health and community service information across Ontario.
                </p>
            </div>

            <div class="service-feature-cards">
                <article class="service-feature-card">
                    <span class="feature-number">01</span>
                    <h3>Trusted Service Directory</h3>
                    <p>Search detailed health and community service listings across Ontario with clear, reliable information.</p>
                </article>

                <article class="service-feature-card">
                    <span class="feature-number">02</span>
                    <h3>Accurate Information</h3>
                    <p>Service details are reviewed, organized, and refreshed to help users find up-to-date information.</p>
                </article>

                <article class="service-feature-card">
                    <span class="feature-number">03</span>
                    <h3>Easy Navigation</h3>
                    <p>Designed to help patients, caregivers, and providers quickly find the right services and support.</p>
                </article>

                <article class="service-feature-card">
                    <span class="feature-number">04</span>
                    <h3>Connected Care Support</h3>
                    <p>Helps community partners and health system teams connect people to relevant local resources.</p>
                </article>
            </div>
        </div>
    </section>

    <section class="why-matters-section full-width-section">
        <div class="container">
            <div class="why-matters-header">
                <span class="section-kicker blue">Why It Matters</span>
                <h2>Clear information helps people access the right support</h2>
                <p>
                    Patients, providers, and communities need trusted service information to make better decisions
                    and connect people with the right care.
                </p>
            </div>

            <div class="why-matters-grid">
                <article class="why-matters-card">
                    <span class="why-number">01</span>
                    <h3>Patients</h3>
                    <p>Patients need clear, simple information to understand available health and community services.</p>
                </article>

                <article class="why-matters-card">
                    <span class="why-number">02</span>
                    <h3>Providers</h3>
                    <p>Providers need accurate service data to guide referrals, care coordination, and system navigation.</p>
                </article>

                <article class="why-matters-card">
                    <span class="why-number">03</span>
                    <h3>Communities</h3>
                    <p>Communities need connected digital tools that make local support easier to find and access.</p>
                </article>
            </div>
        </div>
    </section>
@endif

<section class="related-pages-section full-width-section" aria-label="{{ $isPartners ? 'Related Partner Pages' : 'Related Services' }}">
    <div class="container">
        <div class="related-pages-header">
            <span class="section-kicker blue">{{ $isPartners ? 'Related Partner Pages' : 'Related Services' }}</span>
            <h2>{{ $isPartners ? 'Explore more partner solutions' : 'Explore more THLIN services' }}</h2>
            <p>{{ $isPartners ? 'Solutions tailored for health care, municipalities, social services, and Ontario Health Teams.' : 'Learn more about THLIN tools and support for patients, providers, and community partners.' }}</p>
        </div>

        <div class="related-pages-grid">
            @if ($isPartners)
                <a href="{{ route('pages.show', ['section' => 'partners', 'page' => 'municipalities']) }}" class="related-page-card">
                    <span>01</span>
                    <h3>Municipalities</h3>
                    <p>Community information tools for citizen-centered service navigation.</p>
                </a>
                <a href="{{ route('pages.show', ['section' => 'partners', 'page' => 'social-services']) }}" class="related-page-card">
                    <span>02</span>
                    <h3>Social Services</h3>
                    <p>Digital solutions that empower social services delivery.</p>
                </a>
                <a href="{{ route('pages.show', ['section' => 'products', 'page' => 'healthline']) }}" class="related-page-card">
                    <span>03</span>
                    <h3>thehealthline.ca</h3>
                    <p>Ontario's trusted health and community service directory.</p>
                </a>
            @else
                <a href="{{ route('pages.show', ['section' => 'products', 'page' => 'patient-portals']) }}" class="related-page-card">
                    <span>01</span>
                    <h3>Patient Portals</h3>
                    <p>Digital tools that help patients and caregivers access clear service information.</p>
                </a>
                <a href="{{ route('pages.show', ['section' => 'products', 'page' => 'provider-portals']) }}" class="related-page-card">
                    <span>02</span>
                    <h3>Provider Portals</h3>
                    <p>Support tools designed for providers, care teams, and system partners.</p>
                </a>
                <a href="{{ route('pages.show', ['section' => 'products', 'page' => 'resources']) }}" class="related-page-card">
                    <span>03</span>
                    <h3>Resources</h3>
                    <p>Articles and resources about service directories and system navigation.</p>
                </a>
            @endif
        </div>
    </div>
</section>
